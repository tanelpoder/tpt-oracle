
set arrays 36
set lines 110
set head off
set tab off
set serveroutput on format wrapped
